MAML-Select revision package
Manuscript ID TAI-2026-Mar-L-00619

Upload this zip to Overleaf with New Project -> Upload Project.


CONTENTS
--------
  manuscript_r2_clean.tex      revised manuscript, clean
  manuscript_r2_marked.tex     the same manuscript with round-2 changes in blue
  response_to_reviewers_r2.tex point-by-point response to Reviewer 2
  images/                      4 PDF figures, drawn at final printed size

The class is \documentclass[journal]{IEEEtran}, which is the IEEE journal
template Overleaf ships. Nothing else needs uploading. No .cls or .bst file is
bundled, because supplying an unverified copy is worse than using the one
Overleaf maintains.

The bibliography is written inline as a thebibliography environment, so there is
no .bib file and no BibTeX pass. Compile with pdfLaTeX twice.

    pdflatex manuscript_r2_clean
    pdflatex manuscript_r2_clean

The reply letter uses \documentclass[10pt]{article} and is self-contained. It
carries no figures, no bibliography and no external input, so it compiles on its
own with two pdfLaTeX passes.


LENGTH
------
Eight pages, measured from a compile rather than estimated, against a budget of
eight. Zero errors, zero overfull boxes and zero undefined references in both the
clean and the marked build. The reply letter runs to six pages.


THIS REVISION
-------------
There is no supplementary file. Everything that previously appeared only in the
supplementary material is now in the main manuscript, so the method is described
in exactly one place.

Reviewer 2 wrote a single paragraph. The letter divides it into the seven points
it makes, quotes each verbatim, and answers each in turn.

New in this round is Section V-F, an evaluation at a Dirichlet concentration of
0.1 over three seeds on Fashion-MNIST and CIFAR-10. It reports both halves of
that result, since the compute reduction grows there while CIFAR-10 accuracy
falls.

The implementation is cited in a footnote on the first page. That footnote
currently holds a PLACEHOLDER anonymised link. Generate the real one at
anonymous.4open.science and replace it before submitting, since the author
block is commented out and the submission is blind.


FIGURES
-------
  MAML.pdf                          Fig. 1, system model and round workflow
  fig_convergence_boxed.pdf         Fig. 2, CIFAR-100 convergence
  fig_efficiency_scaling_boxed.pdf  Fig. 3, efficiency, overhead and scaling
  fig_lambda_two_dataset_boxed.pdf  Fig. 4, sensitivity to lambda

All four are vector PDFs. The manuscript sets \graphicspath{{images/}}, so the
folder must keep its name.
